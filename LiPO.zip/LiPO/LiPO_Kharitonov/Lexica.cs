﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LiPO_Kharitonov
{
    class Lexica
    {
        static int firstbegin;
        static string[] splitText;
        static string Text;
        static int Index;
        static int variablesIndex=0;


        static public string start(string txt)
        {
            Index = 0;
            Text = "";
            firstbegin = 0;
            split_Text(txt);
            return Text;
        }

        static void split_Text(string text)
        {
            splitText = text.ToLower().Split(new Char[] {'\n'});
            for (int i = 0; i < splitText.Length; i++)
            {
                if (i <= variablesIndex) continue;
                Index = i;
                splitText[i] = search_Blocks(splitText[i]);
                Text += splitText[i];
            }
            variablesIndex = 0;
        }

        static string search_Blocks(string msg)
        {

            var temp = msg;
            msg = "";
            {
                bool ischeket = false;
                temp = temp.Trim();
               
                //if (temp.Contains("program ") && !ischeket)
                //{
                //    var math = Regex.Match(temp, @"program\s?([^;\s]*);");
                //    var progName = math.Groups[1].Value;
                //    if (string.IsNullOrEmpty(progName))
                //    {
                //        progName = "program";
                //    }
                //    ischeket = true;
                //}

                if (temp.Contains("var") && !ischeket)
                {
                    msg +=
                    var(temp);
                    ischeket = true;
                }

                if (temp.Contains("procedure ") && !ischeket)
                {
                    var math = Regex.Match(temp, @"procedure\s?([^(]*)\s?\(([^)]*)\)\s?;");
                    firstbegin--;
                    var procName = math.Groups[1].Value;
                    var args = math.Groups[2].Value;
                    var Warehose = args.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int k = 0; k < Warehose.Length; k++)
                    {
                        var temp1 = Warehose[k].Trim();
                            var math1 = Regex.Match(temp1, @"([^\:]*)\s?:\s?(\w*)");
                            var vars = math1.Groups[1].Value;
                            var type = math1.Groups[2].Value;
                            if (type == "char") { type = "char"; }
                            if (type == "integer") { type = "int"; }
                            if (type == "byte") { type = "byte"; }
                        var Warehose1 = vars.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        Warehose[k] = "";
                        foreach (var item in Warehose1)
                            {
                                Warehose[k] += type + " " + item + ", ";
                            }
                       }
                    var text = "void "+procName+"("+string.Join(",",Warehose)+")\n";
                    msg+= text.Replace(", )", ")");
                    ischeket = true;
                }

                if (temp.Contains("function ") && !ischeket)
                {
                    var math = Regex.Match(temp, @"function\s?([^(]*)\s?\(([^)]*)\)\s?:\s?([^;]*);");
                    var funcName = math.Groups[1].Value;
                    firstbegin--;
                    var args = math.Groups[2].Value;
                    var returnType = math.Groups[3].Value;
                    var Warehose = args.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int k = 0; k < Warehose.Length; k++)
                    {
                        var temp1 = Warehose[k].Trim();
                        var math1 = Regex.Match(temp1, @"([^\:]*)\s?:\s?(\w*)");
                        var vars = math1.Groups[1].Value.Trim();
                        var type = math1.Groups[2].Value.Trim();
                        if (type == "char") { type = "char"; }
                        if (type == "integer") { type = "int"; }
                        if (type == "byte") { type = "byte"; }
                        var Warehose1 = vars.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        Warehose[k] = "";
                        foreach (var item in Warehose1)
                        {
                            Warehose[k] += type + " " + item + ", ";
                        }
                    }
                    if (returnType == "char") { returnType = "char"; }
                    if (returnType == "integer") { returnType = "int"; }
                    if (returnType == "byte") { returnType = "byte"; }
                    var text = returnType +" " + funcName + "(" + string.Join(",", Warehose) + ")\n";
                    msg += text.Replace(", )", ")");
                    ischeket = true;
                }

                if (temp.Contains("begin") && !ischeket)
                {
                    if (firstbegin == 0)
                    {
                        msg+= "\rint main ()\r{\r";
                        firstbegin -=1000;
                    }
                    else
                    {
                        msg+= "{ \r";
                    }
                    ischeket = true;
                }

                if (temp.Contains("read") && !ischeket)
                {
                    var math = Regex.Match(temp, @"read(ln)?\(([^\)]*)\);");
                    var args = math.Groups[2].Value;
                    msg+= "scanf(" + args.Replace("'", "\"") + ");\n";
                    ischeket = true;
                }

                if (temp.Contains("if ") && !ischeket)
                {
                    if (temp.Contains(" else"))
                    {
                        var ifElse = Regex.Match(temp, @"if\s?([^t]*)then\s?([^;e]*)else([^;]*);");
                        var condition = ifElse.Groups[1].Value.Trim();
                        var actions = ifElse.Groups[2].Value;
                        var unCondition = ifElse.Groups[3].Value;
                        actions = search_Blocks(actions);
                        if (!unCondition.EndsWith(";")) unCondition += ";";
                        unCondition = search_Blocks(unCondition);
                        msg += "\nif (" + condition + ")\n" + "{\n" + actions + "\n}\n" + "else \n{\n" + unCondition + "\n}\n";
                    }
                    else
                    {
                        var ifElse = Regex.Match(temp, @"if\s?([^t]*)then\s?([^;]*)");
                        //"if a > 0 then inc(a);"
                        var condition = ifElse.Groups[1].Value;
                        var actions = ifElse.Groups[2].Value;
                        actions = search_Blocks(actions);
                        msg += "\nif (" + condition + ")\n" + "{\n" + actions + "\n}\n";
                    }
                    ischeket = true;
                }
                if (temp.Contains("inc") && !ischeket)
                {
                    var math = Regex.Match(temp, @"inc\((\w*)\)");
                    var data = math.Groups[1].Value;
                    msg+= data+"++;\n";
                    ischeket = true;
                }
                if (temp.Contains("dec") && !ischeket)
                {
                    var math = Regex.Match(temp, @"dec\((\w*)\)\;");
                    var data = math.Groups[1].Value;
                    msg+= data + "--;\n";
                    ischeket = true;
                }

                if (temp.Contains("for") && !ischeket)
                {
                    var math = Regex.Match(temp, @"for\s([^(to)]*)\s?(down)?to\s(\w*)\s?do\s([^;]*)\;");
                    var loopvar = math.Groups[1].Value;
                    var symbol = math.Groups[2].Value;
                    var limit = math.Groups[3].Value;
                    var action = math.Groups[4].Value;
                    var loopAct = ""; 
                    if (string.IsNullOrEmpty(symbol))
                    {
                        symbol = ">";
                        loopAct="++";
                    }
                    else
                    {
                        symbol = "<";
                        loopAct = "--";
                    }
                    var math1 = Regex.Match(loopvar, @"([^\:]*):=\s?(\d*)");
                    if (string.IsNullOrEmpty(action))
                    {
                        msg+= "for (" + math1.Groups[1].Value + " = " + math1.Groups[2].Value + ";" + math1.Groups[1].Value + symbol + " " + limit + "; " + loopAct + ")\n";
                    }
                    else
                    {
                        action = search_Blocks(action);
                        msg += "for (" + math1.Groups[1].Value + " = " + math1.Groups[2].Value + ";" + math1.Groups[1].Value + symbol + " " + limit + "; " + math1.Groups[1].Value + loopAct + ")\n" + action + "\n";
                    }
                    ischeket = true;
                }

                if (temp.Contains("while ") && !ischeket)
                {
                    var math = Regex.Match(temp, @"while\s?([^\s)]*)\s([<>]{1,2}=?)\s?([^\s]*)\s?do");
                    var firstvar = math.Groups[1].Value;
                    var symbol = math.Groups[2].Value;
                    var secondvar = math.Groups[3].Value;
                    msg+= "while (" + firstvar + " " + symbol + " " + secondvar + ")\n";
                    ischeket = true;
                }

                if (temp.Contains(":=") && !ischeket)
                {
                    var math = Regex.Match(temp, @"([^\:]*)\:=([^\;]*)");
                    var args = math.Groups[2].Value;
                    if (msg.Contains(";"))
                    {
                        msg += math.Groups[1].Value.Trim() + " = " + math.Groups[2].Value.Trim() + " \n";
                    }
                    else
                    msg+= math.Groups[1].Value.Trim() + " = " + math.Groups[2].Value.Trim() + " ;\n";
                    ischeket = true;
                }

                if (temp.Contains("write") && !ischeket)
                {
                    var math = Regex.Match(temp, @"write(ln)?\(([^\)]*)\);");
                    var args = math.Groups[2].Value;
                    msg+= "printf(" + args.Replace("'", "\"") + ");\n";
                    ischeket = true;
                }

                if (temp.Contains("end") && !ischeket)
                {
                    firstbegin++;
                    msg+= "}\n";
                    ischeket = true;
                }
                if (temp != "do" && !ischeket)
                {
                    msg+= temp + "\n";
                    ischeket = true;
                }
            }
            return msg;
        }

        private static string var(string msg)
        {
            var temp = msg;
            int index = Index;
            msg = "";
            bool conkey = false;
            string[] keywords = new string[] { "begin", "procedure", "function" };
            variablesIndex = index;
            for (int i = index + 1; i < splitText.Length-1; i++)
            {
                for (int j = 0; j < keywords.Length; j++)
                {
                    if (splitText[i].Contains(keywords[j]))
                    {
                        variablesIndex = i - 1;
                        conkey = true;
                        break;
                    }
                }
                if (conkey)
                {
                    break;
                }
            }
            for (int i = index; i <= variablesIndex; i++)
            {
                temp = splitText[i].Replace("var", "");
                if (string.IsNullOrEmpty(temp)) continue;
                var math = Regex.Match(temp.Trim(), @"([^\:]*)\:\s?(\w*)\s*;");
                var vars = math.Groups[1].Value.Replace("var ","");
                var type = math.Groups[2].Value;
                if (type == "char") { type="char"; }
                if (type == "integer") { type="int"; }
                if (type == "byte") { type="byte"; }
                var Warehose = vars.Split(new char[] {','}, StringSplitOptions.RemoveEmptyEntries);
                msg+= type + " ";
                for (int m = 0; m < Warehose.Length; m++)
                {
                    if (m==Warehose.Length-1)
                    {
                        msg+= Warehose[m] + ";";
                        break;
                    }
                    msg+= Warehose[m] + ",";
                }
            }
            msg+= "\n";
            return msg;
        }
    }
}
