﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LiPO_Kharitonov
{
    public partial class Form1 : Form
    {
        List<int> lst = new List<int>();
        int position = 0;
        List<string> key_table = new List<string>();
        List<string> var_table = new List<string>();
        List<int> const_table = new List<int>();
        List<string> termin_table = new List<string>();
        List<Res> result_scanned = new List<Res>();
        string buffer = "";
        string s = "";
        int prev_pos = 0;
        bool flagok = false;

        public Form1()
        {
            InitializeComponent();
            tabl_key_termin_entering();
        }

        void tabl_key_termin_entering()
        {
            key_table.Add("program");
            key_table.Add("var");
            key_table.Add("begin");
            key_table.Add("end");
            key_table.Add("procedure");
            key_table.Add("while");
            key_table.Add("do");
            key_table.Add("for");
            key_table.Add("writeln"); key_table.Add("write");
            key_table.Add("readln"); key_table.Add("read");
            key_table.Add("integer");
            key_table.Add("real");
            key_table.Add("function");

            termin_table.Add("(");
            termin_table.Add(")");
            termin_table.Add(";");
            termin_table.Add(":="); termin_table.Add(":");
            termin_table.Add(" ");
            termin_table.Add("=");
            termin_table.Add("+");
            termin_table.Add("-");
            termin_table.Add("<="); termin_table.Add("<");
            termin_table.Add(">="); termin_table.Add(">");
            termin_table.Add("\r");
            termin_table.Add("\n");
            termin_table.Add(".");
            termin_table.Add(",");

        }

        private void btOpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName, System.Text.Encoding.UTF8))
                {
                    richInputCode.Text = Convert.ToString(sr.ReadToEnd().ToLower());
                }
            }
        }

        private void btConvert_Click(object sender, EventArgs e)
        {
            richOutputCode.Clear();
         
            richOutputCode.Text = Lexica.start(richInputCode.Text);
            Syntax();

            textBox1.Text = "";
            List<string> resultat = new List<string>();

            //Proramm
            if (result_scanned[0].pos == 0 && result_scanned[0].t == 1)
            { /*textBox1.Text += "= - ))   Ошибок в терминале Proramm нет!!! \r\n*********************************************************************\r\n"; */}//
            else { textBox1.Text += " Отсутствует programm \n"; };

            //имя
            if (result_scanned[2].t == 2)
            { /*textBox1.Text += "= - ))    Ошибок в имени нет!!! \r\n*********************************************************************\r\n"; */}
            else { textBox1.Text += " Uncorrected name of program \n"; };

            ////Проверка парности (-) 
            {
                int open = 0; int close = 0;
                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if (result_scanned[i].t == 4 && result_scanned[i].pos == 0)
                    { open++; }
                }
                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if (result_scanned[i].t == 4 && result_scanned[i].pos == 1)
                    { close++; }
                }

                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if ((result_scanned[i].t == 4 && result_scanned[i].pos == 0) && (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 1))
                        textBox1.Text += "Пустые скобки\n";
                }

                if (open > close)
                { textBox1.Text += " Пропущены закрывающиеся скобки \n"; };
                if (open < close)
                { textBox1.Text += " Пропущены открывающиеся скобки \n"; }
                else { /*textBox1.Text += "= - ))     Скобки в порядке\r\n*********************************************************************\r\n"; */};
            }

            //Проверка парности begin-end
            {
                int begin = 0; int end = 0;
                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if (result_scanned[i].t == 1 && result_scanned[i].pos == 2)
                    { begin++; }
                }
                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if (result_scanned[i].t == 1 && result_scanned[i].pos == 3)
                    { end++; }
                }
                if (begin > end)
                { textBox1.Text += " (    Пропущен end \n"; };
                if (begin < end)
                { textBox1.Text += " (    Пропущен begin \n"; }
                else { /*textBox1.Text += "= - ))     begin-end в порядке\r\n*********************************************************************\r\n"; */};
            }


            //проверка Writeln/write+Readln/read
            {
                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if (result_scanned[i].t == 1 && (result_scanned[i].pos == 8 || result_scanned[i].pos == 9))
                    {
                        if (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 0)
                        { }
                        else { textBox1.Text += " После writeln/write нет терминального символа \n"; };
                    }
                }
                for (int i = 0; i < result_scanned.Count; i++)
                {
                    if (result_scanned[i].t == 1 && (result_scanned[i].pos == 10 || result_scanned[i].pos == 11))
                    {
                        if (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 0)
                        { }
                        else { textBox1.Text += " После Readln/read нет терминального символа \n"; };
                    }
                }

            }

            Regex reg = new Regex("\"([а-яА-Я]*" + @"\s*|\d*)" + "\"");
            if (!reg.IsMatch(richInputCode.Text))
            { /*textBox1.Text += " \n" ; */}
            else
            {
                textBox1.Text += "Строка с кирилицей ОШИБКА. \n";
            }

            Regex regx = new Regex(@"^([^а-яА-Я]+)$");
            if (regx.IsMatch(richInputCode.Text))
            { /*textBox1.Text += " \n" ; */}
            else
            {
                textBox1.Text += "Строка с кирилицей ОШИБКА. \n";
            }

            //проверка var Begin
            for (int i = 0; i < result_scanned.Count; i++)
            {
                //if (result_scanned[i].t == 1 && result_scanned[i].pos == 1)
                //{
                //    if ((result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 15) && (result_scanned[i - 1].t == 4 && result_scanned[i - 1].pos == 15))
                //    { /*textBox1.Text += "= - ))    С Var все впорядке \r\n*********************************************************************\r\n"; */}
                //    else { textBox1.Text += " Лишний контекст в строке с Var \n"; };
                //}
                if (result_scanned[i].t == 1 && result_scanned[i].pos == 2)
                {
                    if ((result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 14)/*13*/ && (result_scanned[i - 1].t == 4 && result_scanned[i - 1].pos == 14))
                    { /*textBox1.Text += "= - ))    С Begin все впорядке \r\n*********************************************************************\r\n"; */}
                    else { textBox1.Text += " Лишний контекст в строке с Begin  \n"; };
                }
            }

            //проверка Перед точкой только END
            for (int i = 0; i < result_scanned.Count; i++)
            {
                if (result_scanned[i].t == 4 && result_scanned[i].pos == 15)
                {
                    if (result_scanned[i - 1].t == 1 && result_scanned[i - 1].pos == 3)
                    { /*textBox1.Text += "= - ))    С точкой все впорядке \r\n*********************************************************************\r\n"; */}
                    else { textBox1.Text += " Не правильно поставлена точка \n"; };
                }
            }

            //проверка наличия ; или . после END
            for (int i = 0; i < result_scanned.Count; i++)
            {
                if (result_scanned[i].t == 1 && result_scanned[i].pos == 3)
                {
                    if ((result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 2) || (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 15))
                    { /*textBox1.Text += "= - ))    После End все впорядке \r\n*********************************************************************\r\n"; */}
                    else { textBox1.Text += " Ошибка конструкции \n"; };
                }
            }
            for (int i = result_scanned.Count - 1; i > 0; i--)
            {
                if (result_scanned[i].t == 2 && !lst.Contains(result_scanned[i].pos))
                {
                    if (result_scanned[i].pos != 0) textBox1.Text += " Не существует переменной \n";
                }
            }
            //проверка последнего END на точкой
            int i_nado = 0;
            for (int i = result_scanned.Count - 1; i > 0; i--)
            {
                if (result_scanned[i].t == 1 && result_scanned[i].pos == 3)
                {
                    i_nado = i;
                    if (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 15)
                    { /*textBox1.Text += "= - ))    Последний End с точкой \r\n*********************************************************************\r\n"; */}
                    else { textBox1.Text += " Пропущена точка после end \n"; };
                    break;
                }
            }
            //проверка предыдущих END на ;
            for (int i = i_nado - 1; i > 0; i--)
            {
                if (result_scanned[i].t == 1 && result_scanned[i].pos == 3)
                {
                    i_nado = i;
                    if (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 2)
                    { /*textBox1.Text += "= - ))    предыдущие End с ; \r\n*********************************************************************\r\n"; */}
                    else { textBox1.Text += " Пропущена; после end \n"; };
                }
            }

            //проверка +-
            for (int i = 0; i < result_scanned.Count; i++)
            {

                if (result_scanned[i].t == 4 && (result_scanned[i].pos == 7 || result_scanned[i].pos == 8))
                {
                    if (result_scanned[i + 1].t == 2 || result_scanned[i + 1].t == 3) { }
                    else
                    if ((result_scanned[i].pos == 8 || result_scanned[i].pos == 7) && result_scanned[i].t == 1 && (result_scanned[i + 1].t == 3 || result_scanned[i + 1].t == 2) || (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 0)) { }
                    else
                    if ((result_scanned[i + 1].t == 2 || result_scanned[i + 1].t == 3 || (result_scanned[i + 1].t == 4 && result_scanned[i + 1].pos == 0)) && (result_scanned[i - 1].t == 2 || result_scanned[i - 1].t == 3 || (result_scanned[i - 1].t == 4 && result_scanned[i - 1].pos == 1)))
                    { /*textBox1.Text += "вокруг + или - все хорошо \r\n"; */}
                    else { textBox1.Text += "Неправильное арифметическое выражение\n"; };
                }
            }
            if (textBox1.Text == "") { textBox1.Text = "Программа без ошибок"; }
        }

        public void Syntax()
        {
            bool flag = false;
            {
                s = richInputCode.Text;
                result_scanned.Clear();
                var_table.Clear();
                const_table.Clear();
                for (int i = 0; i < s.Length; i++)
                {
                    //проверка на терминальный символ
                    for (int j = 0; j < termin_table.Count; j++)
                    {
                        position = 0;
                        string kk = "";
                        if (termin_table[j].Length <= s.Length - i)
                            for (int jj = i; jj < i + termin_table[j].Length; jj++)
                                kk += s[jj];
                        if (kk == termin_table[j])
                        {
                            position = i + termin_table[j].Length;

                            result_scanned.Add(new Res(4, j));
                            if (flag) prev_pos = position;
                            flag = true;
                            break;
                        }
                    }
                    if (flag == false) buffer += s[i];
                    if (flag && buffer != "")
                    {
                        flag = false;
                        for (int jj = 0; jj < key_table.Count; jj++)
                            if (buffer == key_table[jj])
                            {
                                if (buffer == "var") flagok = true;
                                if (buffer == "real") flagok = false;
                                result_scanned.Insert(result_scanned.Count - 1, new Res(1, jj));

                                buffer = "";
                                goto ex;
                            }
                        try
                        {
                            int chislo = Convert.ToInt32(buffer);
                            if (const_table.Contains(chislo))
                            { }
                            else
                            { const_table.Add(chislo); }
                            result_scanned.Insert(result_scanned.Count - 1, new Res(3, (int)const_table.IndexOf(chislo)));
                        }
                        catch (Exception)
                        {
                            //переменные
                            if (var_table.Contains(buffer))
                            { }
                            else
                            {
                                var_table.Add(buffer);
                                if (flagok) lst.Add((int)var_table.IndexOf(buffer));
                                if (buffer[0].ToString() == "'") lst.Add((int)var_table.IndexOf(buffer));
                            }
                            result_scanned.Insert(result_scanned.Count - 1, new Res(2, (int)var_table.IndexOf(buffer)));
                        }

                        prev_pos = position;
                        buffer = "";
                    }
                ex:
                    flag = false;
                }
            }
        }
    }

    public class Res
    {
        public Res(int a, int b)
        {
            t = a;
            pos = b;
        }
        public int t;
        public int pos;
    }
}